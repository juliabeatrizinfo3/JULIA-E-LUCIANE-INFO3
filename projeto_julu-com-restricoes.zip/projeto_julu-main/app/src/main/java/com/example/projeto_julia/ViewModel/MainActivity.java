package com.example.projeto_julia.ViewModel;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import com.example.projeto_julia.CadastroActivity;
import com.example.projeto_julia.MenuActivity;
import com.example.projeto_julia.R;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    private EditText usuario, senha;
    private Button botao;
    private FirebaseAuth auth;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() != null) { abrirMenu(); return; }
        setContentView(R.layout.activity_main);
        usuario = findViewById(R.id.Usuario_input);
        senha = findViewById(R.id.Senha_input);
        botao = findViewById(R.id.btnLogin);
        TextView cadastrar = findViewById(R.id.txtCadastrar);
        TextView esqueci = findViewById(R.id.txtEsqueciSenha);
        cadastrar.setOnClickListener(v -> startActivity(new Intent(this, CadastroActivity.class)));
        esqueci.setOnClickListener(v -> recuperarSenha());
        botao.setOnClickListener(v -> entrar());
    }

    private void entrar() {
        String email = usuario.getText().toString().trim();
        String password = senha.getText().toString();
        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            usuario.setError("Informe um e-mail válido"); usuario.requestFocus(); return;
        }
        if (password.isEmpty()) { senha.setError("Digite sua senha"); senha.requestFocus(); return; }
        botao.setEnabled(false);
        auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
            botao.setEnabled(true);
            if (task.isSuccessful()) abrirMenu();
            else Toast.makeText(this, "Não foi possível entrar. Verifique e-mail, senha e conexão.", Toast.LENGTH_LONG).show();
        });
    }

    private void recuperarSenha() {
        String email = usuario.getText().toString().trim();
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            usuario.setError("Digite seu e-mail para receber a recuperação"); usuario.requestFocus(); return;
        }
        auth.sendPasswordResetEmail(email).addOnCompleteListener(task ->
            Toast.makeText(this, task.isSuccessful() ? "Se o e-mail estiver cadastrado, você receberá as instruções de recuperação." : "Não foi possível enviar. Verifique a conexão e tente novamente.", Toast.LENGTH_LONG).show());
    }

    private void abrirMenu() {
        Intent intent = new Intent(this, MenuActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent); finish();
    }
}
