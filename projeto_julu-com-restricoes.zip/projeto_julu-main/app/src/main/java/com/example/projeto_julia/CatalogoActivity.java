package com.example.projeto_julia;
import android.content.*;import android.os.Bundle;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;
public class CatalogoActivity extends AppCompatActivity {
 String[] nomes={"Buquê de Rosas","Girassóis","Cesta de Flores"}; double[] precos={89.90,69.90,119.90};
 @Override protected void onCreate(Bundle b){super.onCreate(b); if (!AuthGuard.requireLogin(this)) return;LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(24,32,24,24);l.setBackgroundColor(0xFFFFF8FA);TextView h=new TextView(this);h.setText("Produtos");h.setTextSize(28);h.setTextColor(0xFF542B35);h.setTypeface(null,1);l.addView(h);Button voltar=new Button(this);voltar.setText("← Voltar");voltar.setOnClickListener(v->finish());l.addView(voltar);
 for(int i=0;i<nomes.length;i++){final int x=i;TextView t=new TextView(this);t.setText(nomes[i]+"\n"+String.format(java.util.Locale.forLanguageTag("pt-BR"),"R$ %.2f",precos[i]));t.setTextSize(19);t.setTextColor(0xFF542B35);t.setPadding(12,24,12,12);l.addView(t);Button a=new Button(this);a.setText("Adicionar ao carrinho");a.setOnClickListener(v->{getSharedPreferences("carrinho",MODE_PRIVATE).edit().putString("item",nomes[x]).putInt("qtd",1).putFloat("preco",(float)precos[x]).apply();Toast.makeText(this,"Produto adicionado ao carrinho",Toast.LENGTH_SHORT).show();});l.addView(a);}
 setContentView(l);}
}
