package com.example.projeto_julia;

import android.app.Activity;
import android.content.Intent;
import com.example.projeto_julia.ViewModel.MainActivity;
import com.google.firebase.auth.FirebaseAuth;

/** Impede abrir telas internas sem uma sessão autenticada. */
public final class AuthGuard {
    private AuthGuard() {}
    public static boolean requireLogin(Activity activity) {
        if (FirebaseAuth.getInstance().getCurrentUser() != null) return true;
        Intent intent = new Intent(activity, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        activity.startActivity(intent);
        activity.finish();
        return false;
    }
}
