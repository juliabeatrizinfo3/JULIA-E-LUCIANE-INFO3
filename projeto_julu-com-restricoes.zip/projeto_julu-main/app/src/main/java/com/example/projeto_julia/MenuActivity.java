package com.example.projeto_julia;
import android.content.Intent;import android.os.Bundle;import android.widget.Button;import androidx.appcompat.app.AppCompatActivity;
public class MenuActivity extends AppCompatActivity {
 @Override protected void onCreate(Bundle b){super.onCreate(b); if (!AuthGuard.requireLogin(this)) return;setContentView(R.layout.activity_menu);
  findViewById(R.id.btnProdutos).setOnClickListener(v->startActivity(new Intent(this,CatalogoActivity.class)));
  findViewById(R.id.btnFavoritos).setOnClickListener(v->startActivity(new Intent(this,FavoritosActivity.class)));
  findViewById(R.id.btnCarrinho).setOnClickListener(v->startActivity(new Intent(this,CarrinhoActivity.class)));
  findViewById(R.id.btnPedidos).setOnClickListener(v->startActivity(new Intent(this,PedidosActivity.class)));
  findViewById(R.id.btnPerfil).setOnClickListener(v->startActivity(new Intent(this,PerfilActivity.class)));
 }
}
