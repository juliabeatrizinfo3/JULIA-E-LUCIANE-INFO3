package com.example.projeto_julia;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class CadastroActivity extends AppCompatActivity {
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private EditText nome, email, usuario, senha, confirmar;
    private Button cadastrar;
    private TextView entrar;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_cadastro);
        auth = FirebaseAuth.getInstance(); db = FirebaseFirestore.getInstance();
        nome=findViewById(R.id.edtNome); email=findViewById(R.id.edtEmail);
        usuario=findViewById(R.id.edtUsuario); senha=findViewById(R.id.edtSenha);
        confirmar=findViewById(R.id.edtConfirmarSenha); cadastrar=findViewById(R.id.btnCadastrar);
        entrar=findViewById(R.id.txtEntrar);
        cadastrar.setOnClickListener(v -> criarConta());
        entrar.setOnClickListener(v -> finish());
    }
    private void criarConta() {
        String n=nome.getText().toString().trim(), e=email.getText().toString().trim();
        String u=usuario.getText().toString().trim(), s=senha.getText().toString(), c=confirmar.getText().toString();
        if(n.isEmpty()||e.isEmpty()||u.isEmpty()||s.isEmpty()||c.isEmpty()){ aviso("Preencha todos os campos."); return; }
        if(!Patterns.EMAIL_ADDRESS.matcher(e).matches()){ email.setError("Informe um e-mail válido"); email.requestFocus(); return; }
        if(s.length()<6){ senha.setError("A senha deve ter pelo menos 6 caracteres"); senha.requestFocus(); return; }
        if(!s.equals(c)){ confirmar.setError("As senhas não coincidem"); confirmar.requestFocus(); return; }
        cadastrar.setEnabled(false);
        auth.createUserWithEmailAndPassword(e,s).addOnCompleteListener(task -> {
            if(!task.isSuccessful()){ cadastrar.setEnabled(true); aviso(task.getException()!=null?task.getException().getLocalizedMessage():"Não foi possível criar a conta."); return; }
            String uid=auth.getCurrentUser().getUid(); Map<String,Object> dados=new HashMap<>();
            dados.put("nome",n); dados.put("email",e); dados.put("usuario",u);
            db.collection("usuarios").document(uid).set(dados).addOnCompleteListener(save -> {
                if(!save.isSuccessful()) aviso("Conta criada, mas não foi possível salvar o perfil. Verifique o Firestore.");
                startActivity(new Intent(this, MenuActivity.class)); finish();
            });
        });
    }
    private void aviso(String msg){ Toast.makeText(this,msg,Toast.LENGTH_LONG).show(); }
}
