package com.example.projeto_julia;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class CarrinhoActivity extends AppCompatActivity {
 @Override protected void onCreate(Bundle b){ super.onCreate(b); if (!AuthGuard.requireLogin(this)) return; LinearLayout root=base("Meu carrinho");
  android.content.SharedPreferences p=getSharedPreferences("carrinho",MODE_PRIVATE); String item=p.getString("item",""); int qtd=p.getInt("qtd",0); double preco= p.getFloat("preco",0f);
  TextView resumo=texto(item.isEmpty()?"Seu carrinho está vazio.":item+"\nQuantidade: "+qtd+"\nSubtotal: "+moeda(preco*qtd)); root.addView(resumo);
  Button pagar=botao("Continuar para pagamento"); pagar.setEnabled(!item.isEmpty()); pagar.setOnClickListener(v->startActivity(new Intent(this,PagamentoActivity.class))); root.addView(pagar);
  Button limpar=botao("Limpar carrinho"); limpar.setOnClickListener(v->{p.edit().clear().apply(); Toast.makeText(this,"Carrinho limpo",Toast.LENGTH_SHORT).show(); recreate();}); root.addView(limpar); setContentView(root);
 }
 LinearLayout base(String t){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(32,40,32,32);l.setBackgroundColor(0xFFFFF8FA); TextView h=texto(t);h.setTextSize(26);h.setTypeface(null,1);l.addView(h);Button v=botao("← Voltar");v.setOnClickListener(x->finish());l.addView(v);return l;}
 TextView texto(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(0xFF542B35);t.setTextSize(18);t.setPadding(0,20,0,20);return t;} Button botao(String s){Button b=new Button(this);b.setText(s);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFA84D67));b.setTextColor(-1);return b;} String moeda(double v){return String.format(java.util.Locale.forLanguageTag("pt-BR"),"R$ %.2f",v);}
}
